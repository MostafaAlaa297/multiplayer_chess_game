# Hands on: Real-time Chess
## LAB RESOURCES

This folder contains the image and library references required if you're following the steps of this lab.

When instructed by the lab manual, copy the contents of this folder to your project folder.
* /chess/public/img
* /chess/public/lib